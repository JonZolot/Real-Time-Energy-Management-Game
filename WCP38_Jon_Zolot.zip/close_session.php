<?php
//enters into session variables
session_start();

//clears session variables
session_destroy();
?>