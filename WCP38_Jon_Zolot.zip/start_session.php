<?php
//starts session variables
session_start();




?>

